from django.shortcuts import render
from django.http import HttpResponse
from student.models import Studentdetails
from student.models import Coursedetails
from student.models import Enrollment
from django.db import connection
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def home(request):
    context = {'firstname': 'Matthew', 'lastname':'Asbill'}
    return render(request, 'student/home.html', context)

def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

@login_required
def studentdetails(request):
    student = Studentdetails.objects.all()
    paginator = Paginator(student, 10)
    page = request.GET.get('page')   #Retrieve page number
    studentdata = paginator.get_page(page)   #Retrieve data for that page
    
    return render(request, 'student/studentdetails.html', {'data':studentdata})

@login_required
def coursedetails(request):
    course = Coursedetails.objects.all()
    paginator = Paginator(course, 10)
    page = request.GET.get('page')   #Retrieve page number
    coursedata = paginator.get_page(page)   #Retrieve data for that page

    return render(request, 'student/coursedetails.html', {'data':coursedata})

@login_required
def enrollment(request):
    student = Studentdetails.objects.all()
    course = Coursedetails.objects.all()
    enrollmentdata = ''
    if('studentid' in request.session):
        enrollmentdata = Enrollment.objects.filter(studentid = request.session['studentid'])
    if('idname' in request.GET and 'cname' not in request.GET):
        idname = request.GET.get('idname')
        request.session['studentid'] = idname
        return HttpResponse('Success')
    if('idname' in request.GET and 'cname' in request.GET):
        idname = request.GET.get('idname')
        cname = request.GET.get('cname')
        enrollmentdata = Enrollment.objects.filter(studentid = idname)
        for row in enrollmentdata:
            if row.coursetitle == cname:   
                return HttpResponse('Error')
        newdata = Enrollment(studentid = idname, coursetitle = cname)
        newdata.save()
        return HttpResponse("Success")
    return render(request, 'student/enrollment.html', {'student': student, 'course': course, 'enrollment': enrollmentdata})
