from django.contrib import admin
from student.models import Studentdetails
from student.models import Coursedetails

admin.site.register(Studentdetails)
admin.site.register(Coursedetails)

# Register your models here.
