from django.db import models

class Studentdetails(models.Model):
    studentid = models.IntegerField()
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    major = models.CharField(max_length=500)
    year = models.CharField(max_length=500)
    gpa = models.CharField(max_length=500)

class Coursedetails(models.Model):
    courseid = models.IntegerField()
    coursetitle = models.CharField(max_length=500)
    coursename = models.CharField(max_length=500)
    coursesection = models.IntegerField()
    coursedepartment = models.CharField(max_length=500)
    instructorname = models.CharField(max_length=500)

class Enrollment(models.Model):
    studentid = models.IntegerField()
    coursetitle = models.CharField(max_length=500)
   

# Create your models here.
